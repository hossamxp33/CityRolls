package com.codesroots.osamaomar.shopgate.usecases

import com.codesroots.osamaomar.shopgate.domain.ServerGateway

class repositry(private  val serverGateway: ServerGateway ) {


}
