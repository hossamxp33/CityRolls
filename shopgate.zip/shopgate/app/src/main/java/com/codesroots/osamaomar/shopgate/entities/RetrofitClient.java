package com.codesroots.osamaomar.shopgate.entities;

public class RetrofitClient {

}