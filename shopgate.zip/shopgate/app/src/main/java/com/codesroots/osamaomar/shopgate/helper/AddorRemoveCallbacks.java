package com.codesroots.osamaomar.shopgate.helper;



public interface AddorRemoveCallbacks {

    public void onAddProduct();
    public void onRemoveProduct();
    public void onClearCart();
}
