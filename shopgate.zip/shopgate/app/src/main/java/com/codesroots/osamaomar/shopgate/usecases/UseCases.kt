package com.codesroots.osamaomar.shopgate.usecases

//
//fun retrieveUserOrders(userid:Int,progressLoading:MutableLiveData<Boolean>,result:MutableLiveData<MyOrders>,
//                       loadingthrowable:MutableLiveData<Throwable>,)