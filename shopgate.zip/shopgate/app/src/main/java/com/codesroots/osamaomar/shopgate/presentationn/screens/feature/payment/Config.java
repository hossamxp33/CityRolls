package com.codesroots.osamaomar.shopgate.presentationn.screens.feature.payment;

public class Config {

   // public static  final String PAYPAL_CLIENT_ID = "AZZ52sPkIfN_APjH54lQ3Rb6g7k-X7_nIXGZP1YjwB95ksoLUh0bkpOCBTYaHUXg58wTZl6fIvAT_C2J";
    public static  final String PAYPAL_CLIENT_ID = "AUM90oLgQWe1wmWlH1UhclcByEM0hPaV6GSUEimQMtFr_U3X9lgA-c7HY0cU-c2ato_KzPGbyNATo-6t";


}
