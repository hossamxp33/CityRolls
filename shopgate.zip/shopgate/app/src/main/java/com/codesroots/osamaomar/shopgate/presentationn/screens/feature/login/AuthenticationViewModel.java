package com.codesroots.osamaomar.shopgate.presentationn.screens.feature.login;

import android.arch.lifecycle.ViewModel;

public class AuthenticationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
