package com.codesroots.osamaomar.shopgate.entities;

public class names {

    public static String PRODUCT_ID = "PRODUCT_ID";
    public static String SUB_CAT_ID = "SUB_CAT_ID";
    public static String CAT_ID = "CAT_ID";
    public static String CAT_TYPE = "CAT_TYPE";
    public static String ORDER_ID = "ORDER_ID";
    public static String SUBCATES_NAME = "SUBCATES_NAME";
    public static String CAT_NAME = "CAT_NAME";
    public static String PRODUCT_PHOTO = "PRODUCT_PHOTO";
    public static String PRODUCT_NAME = "PRODUCT_NAME";
    public static String ORDER = "ORDER";
    public static final String FULL_ADDRESS = "full_address";
    public static final String USER_LAT = "user_lat";
    public static final String USER_LANG = "user_lang";
}
