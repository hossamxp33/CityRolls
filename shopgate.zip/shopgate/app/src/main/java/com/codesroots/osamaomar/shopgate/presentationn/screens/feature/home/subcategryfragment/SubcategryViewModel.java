package com.codesroots.osamaomar.shopgate.presentationn.screens.feature.home.subcategryfragment;

import android.arch.lifecycle.ViewModel;

public class SubcategryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
