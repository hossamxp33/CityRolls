package com.codesroots.osamaomar.shopgate.presentationn.screens.feature.home.mainfragment;

        import android.arch.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
