package com.codesroots.osamaomar.shopgate.presentationn.screens.feature.paypal;

public class Config {

    //public static  final String PAYPAL_CLIENT_ID = "AZZ52sPkIfN_APjH54lQ3Rb6g7k-X7_nIXGZP1YjwB95ksoLUh0bkpOCBTYaHUXg58wTZl6fIvAT_C2J";
    public static  final String PAYPAL_CLIENT_ID = "Aery7sa0Sq-5SNTtxA1h9aKtJKlotms4PVRuoq7jNmyTea2_PLt8rPsfWdcYtT2b7xanxsbuJ-CQFxf4";


}
